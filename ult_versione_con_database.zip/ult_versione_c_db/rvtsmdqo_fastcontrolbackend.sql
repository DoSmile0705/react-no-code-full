-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Creato il: Set 28, 2023 alle 16:19
-- Versione del server: 10.6.14-MariaDB-cll-lve-log
-- Versione PHP: 8.1.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rvtsmdqo_fastcontrolbackend`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `table_graphs`
--

CREATE TABLE `table_graphs` (
  `id` int(10) UNSIGNED NOT NULL,
  `graph` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci ROW_FORMAT=DYNAMIC;

--
-- Dump dei dati per la tabella `table_graphs`
--

INSERT INTO `table_graphs` (`id`, `graph`) VALUES
(6, '{\"graphJSON\":{\"tableDict\":{\"t_tzuZzS2lBjQ1x52NCk0\":{\"id\":\"t_tzuZzS2lBjQ1x52NCk0\",\"name\":\"Table_Name_1\",\"x\":268,\"y\":72,\"fields\":[{\"id\":\"2WuVoWc7ipa36JxFkYbe-\",\"name\":\"id\",\"type\":\"INTEGER\",\"note\":\"\",\"dbdefault\":\"\",\"pk\":true,\"increment\":true},{\"id\":\"o05VObrEZkBEfHqSqqk1C\",\"name\":\"new_item1\",\"type\":\"NUMERIC\",\"note\":\"\",\"dbdefault\":\"\",\"unique\":false}]},\"t8xF916xYPgpUhVDnDQPR\":{\"id\":\"t8xF916xYPgpUhVDnDQPR\",\"name\":\"Table_Name_2\",\"x\":556,\"y\":72,\"fields\":[{\"id\":\"Ff1DFS2h2KTaNcmOMxHgt\",\"name\":\"id\",\"type\":\"INTEGER\",\"note\":\"\",\"dbdefault\":\"\",\"pk\":true,\"increment\":true},{\"id\":\"l3SjJrCAs4pAsM5InKRHS\",\"name\":\"new_item1\",\"type\":\"NUMERIC\",\"note\":\"\",\"dbdefault\":\"\",\"unique\":false}]}},\"linkDict\":{},\"box\":{\"x\":0,\"y\":0,\"w\":1210,\"h\":620,\"clientW\":1210,\"clientH\":620},\"name\":\"Untitled graph 0\",\"connectConfig\":{\"hostname\":\"localhost\",\"username\":\"rvtsmdqo_fastcontrol\",\"password\":\"fastcontrol2023?\",\"database\":\"rvtsmdqo_fastcontrol\"},\"updatedAt\":1695062549480,\"createdAt\":1695062405773}}'),
(7, '{\"graphJSON\":{\"tableDict\":{\"99UjEy-a13B0BdnjYmIq3\":{\"id\":\"99UjEy-a13B0BdnjYmIq3\",\"name\":\"Table_Name_1\",\"x\":269,\"y\":72,\"fields\":[{\"id\":\"wQfpx70iol7w1hrBwPXp5\",\"name\":\"id\",\"type\":\"INTEGER\",\"note\":\"\",\"dbdefault\":\"\",\"pk\":true,\"increment\":true},{\"id\":\"xpv2MpmN4x766_NjYN1yD\",\"name\":\"new_item1\",\"type\":\"NUMERIC\",\"note\":\"\",\"dbdefault\":\"\",\"unique\":false},{\"id\":\"sZvszM4VjhJ_KsCMvw2KY\",\"name\":\"new_item2\",\"type\":\"NUMERIC\",\"note\":\"\",\"dbdefault\":\"\",\"unique\":false}]},\"xo3HDNhFkELUxWhzyE2QM\":{\"id\":\"xo3HDNhFkELUxWhzyE2QM\",\"name\":\"Table_Name_2\",\"x\":799,\"y\":278,\"fields\":[{\"id\":\"iNwpWcOx9dOr4wQRutyRA\",\"name\":\"id\",\"type\":\"INTEGER\",\"note\":\"\",\"dbdefault\":\"\",\"pk\":true,\"increment\":true},{\"id\":\"0slm4dzR0NQpaQ-BWQX2H\",\"name\":\"new_item1\",\"type\":\"NUMERIC\",\"note\":\"\",\"dbdefault\":\"\",\"unique\":false}]},\"A2zXnENbrI01cdu4xt3K4\":{\"id\":\"A2zXnENbrI01cdu4xt3K4\",\"name\":\"Table_Name_3\",\"x\":319,\"y\":287,\"fields\":[{\"id\":\"kISowhCPZ3xrDhCS4fs05\",\"name\":\"id\",\"type\":\"INTEGER\",\"note\":\"\",\"dbdefault\":\"\",\"pk\":true,\"increment\":true},{\"id\":\"NKsw9w1iJ-cdSqlszVzuY\",\"name\":\"new_item1\",\"type\":\"NUMERIC\",\"note\":\"\",\"dbdefault\":\"\",\"unique\":false},{\"id\":\"ueM2cCpqRFYKWFJKM_Bie\",\"name\":\"new_item2\",\"type\":\"NUMERIC\",\"note\":\"\",\"dbdefault\":\"\",\"unique\":false}]}},\"linkDict\":{\"17v1fknf9NjPMNFjTdYMK\":{\"id\":\"17v1fknf9NjPMNFjTdYMK\",\"name\":null,\"endpoints\":[{\"id\":\"99UjEy-a13B0BdnjYmIq3\",\"fieldId\":\"wQfpx70iol7w1hrBwPXp5\",\"relation\":\"1\"},{\"id\":\"xo3HDNhFkELUxWhzyE2QM\",\"fieldId\":\"0slm4dzR0NQpaQ-BWQX2H\",\"relation\":\"*\"}]}},\"box\":{\"x\":1,\"y\":0,\"w\":1278,\"h\":620,\"clientW\":1278,\"clientH\":620},\"name\":\"testdatabse2023_09\",\"connectConfig\":{\"hostname\":\"localhost\",\"username\":\"rvtsmdqo_testdatabse2023_09\",\"password\":\"fastcontrol2023?\",\"database\":\"rvtsmdqo_testdatabse2023_09\"},\"updatedAt\":1695909537611,\"createdAt\":1695062568910}}');

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `table_graphs`
--
ALTER TABLE `table_graphs`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `table_graphs`
--
ALTER TABLE `table_graphs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
